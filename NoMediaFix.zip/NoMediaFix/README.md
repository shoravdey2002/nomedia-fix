# nomedia-fix — README (বাংলায়)

## এই অ্যাপ কী করে

এই অ্যাপ ঠিক একটা নির্দিষ্ট কাজ করে — `/storage/<volume-id>/Android/data/.nomedia` পথে ফাইল থাকলে সেটা খুঁজে ডিলিট করে। আর কোনো ফোল্ডার বা অন্য কোনো `.nomedia` ফাইল touch করে না।

দুইভাবে ট্রিগার করা যায়ঃ
- **RUN NOW** — সরাসরি এক ক্লিকে এখনই চালানোর জন্য।
- **ARM** — টগল করলে অ্যাপ ব্যাকগ্রাউন্ডে "স্ট্যান্ডবাই" মোডে চলে যায়। তারপর কার্ড খুলে আবার ঢোকালে, ঠিক সেই মুহূর্তে অ্যাপ নিজে থেকে কাজটা করে দেয় — তোমাকে আর কিছু চাপতে হয় না।

এটা continuous/সবসময় চলা background monitoring না — শুধু যখন তুমি ARM করো, তখনই পরের কার্ড-ইনসার্টের জন্য watch করে।

`Android/data` ফোল্ডারে non-root অ্যাপের পক্ষে স্বাভাবিকভাবে ঢোকা অসম্ভব (Google নিজেই Android 11 থেকে এটা ব্লক করে রেখেছে), তাই এই অ্যাপ **Shizuku** ব্যবহার করে — root না করেই privileged access পাওয়ার একটা legitimate, widely-used উপায়।

---

## ⚠️ সবচেয়ে গুরুত্বপূর্ণ অংশ — Shizuku সেটআপ (এটা ছাড়া অ্যাপ কিছুই করতে পারবে না)

Shizuku নিজেই একটা আলাদা অ্যাপ, যেটা আগে থেকে ইনস্টল ও "চালু" থাকতে হবে। এটা একটা সাধারণ অ্যাপ install করার মতো সহজ না — একটু technical, কিন্তু রুট করার চেয়ে অনেক সহজ।

**একবারের সেটআপঃ**

1. **Shizuku অ্যাপ ইনস্টল করো** — Play Store থেকে "Shizuku" সার্চ করো, বা [shizuku.rikka.app/download](https://shizuku.rikka.app/download/) থেকে।
2. **Developer options চালু করো** — Settings → About phone → MIUI version এ ৭ বার ট্যাপ করো ("You are now a developer" মেসেজ আসবে)।
3. **Wireless debugging চালু করো** — Settings → Additional settings → Developer options → Wireless debugging → ON করো।
4. **Shizuku চালু করো** — Shizuku অ্যাপ ওপেন করে "Start via Wireless debugging" এ ট্যাপ করো। এটা তোমাকে Wireless debugging সেটিংসে নিয়ে যাবে পেয়ারিং করার জন্য (প্রথমবার একটা কোড দিয়ে পেয়ার করতে হবে, Shizuku অ্যাপের ভেতরেই নির্দেশনা দেখাবে)।
5. Shizuku অ্যাপে "Running" status দেখালে, এই অ্যাপ (nomedia-fix) ওপেন করো এবং **"request shizuku permission"** বাটনে চাপ দাও। Shizuku থেকে একটা permission popup আসবে — Allow করো।

**⚠️ জরুরি ক্যাভিয়েট — প্রতি রিবুটে আবার করতে হবে:** ফোন restart হলে Shizuku বন্ধ হয়ে যায় (এটা Shizuku-এর নিজের সীমাবদ্ধতা, root ছাড়া এটা চিরস্থায়ীভাবে persist করানো যায় না)। রিবুটের পর Shizuku অ্যাপ খুলে আবার "Start via Wireless debugging" চাপতে হবে (প্রথমবারের মতো পুরো pairing আবার করতে হয় না, সাধারণত এক ট্যাপেই হয়ে যায়, যদি না MIUI নিজেই Wireless debugging টগল বন্ধ করে দেয়)।

---

## কীভাবে build করবে — দুইটা উপায়

### উপায় ১ — কম্পিউটার ছাড়া, সরাসরি ফোন থেকে (GitHub Actions)

এই রিপোতে `.github/workflows/build.yml` আছে যেটা GitHub-এর নিজস্ব cloud server-এ build চালায় — কোনো local PC/Android SDK লাগে না। এই রিপোর zip আপলোড করে এই workflow ট্রিগার করলে কিছুক্ষণ পর "Actions" ট্যাব থেকে রেডি APK ডাউনলোড করা যাবে। (বিস্তারিত স্টেপ এই রিপোর সাথে দেওয়া চ্যাট-টিউটোরিয়ালে আছে।)

### উপায় ২ — Android Studio (কম্পিউটার থাকলে)

আমার sandbox এ Android SDK এবং Google এর Maven repository (dl.google.com) এর access নেই, তাই আমি নিজে compile করে APK বানিয়ে test করতে পারিনি। কোডটা আমি Shizuku-এর official documentation যাচাই করে লিখেছি এবং সব ফাইলের id/string/package reference নিজে cross-check করেছি, কিন্তু আসল compile-time test হবে তোমার Android Studio তে।

1. [Android Studio](https://developer.android.com/studio) ইনস্টল করো (ফ্রি)।
2. zip extract করো, Android Studio তে **Open** → `NoMediaFix` ফোল্ডার সিলেক্ট করো।
3. Gradle sync হতে দাও (প্রথমবার ইন্টারনেট লাগবে — Shizuku লাইব্রেরি ডাউনলোড হবে)।
4. ফোন কানেক্ট করে **Run** চাপো, বা **Build → Generate Signed Bundle / APK** দিয়ে APK বানিয়ে সরাসরি ফোনে ইনস্টল করো।

যদি Gradle sync এ কোনো Shizuku-related মেথড না পাওয়া যায় (unresolved reference), সেটা সম্ভবত Shizuku-এর কোনো API খুব সাম্প্রতিক ভার্সনে নাম পরিবর্তন হয়েছে — সেক্ষেত্রে [Shizuku-API এর official GitHub README](https://github.com/RikkaApps/Shizuku-API) দেখলে ঠিক মেথড নামটা পাওয়া যাবে।

---

## অ্যাপ কীভাবে ব্যবহার করবে

1. Shizuku সেটআপ শেষ করে (উপরের অংশ) **"request shizuku permission"** চাপো — status এ `[shizuku] ready ✓` দেখাবে।
2. সমস্যা হলে দুই রকম ভাবে চালাতে পারোঃ
   - **এখনই সমস্যা থাকলে** → **RUN NOW** চাপো, log এ রিপোর্ট দেখাবে।
   - **কার্ড খুলে আবার ঢোকাবে** → প্রথমে **ARM** চাপো, তারপর কার্ড খুলে আবার ফোনে ঢোকাও — অ্যাপ নিজে থেকে কাজ করে একটা নোটিফিকেশন দেখাবে।
3. নিচের log console এ প্রতিটা একশন এর টাইমস্ট্যাম্পসহ রেকর্ড থাকবে — ঠিক কী delete হলো বা কিছু পাওয়া যায়নি, সবকিছু transparent ভাবে দেখা যাবে।

---

## ডিজাইনের সীমাবদ্ধতা ও সততার সাথে কিছু কথা

- এই অ্যাপ **শুধু** `/storage/*/Android/data/.nomedia` পথ চেক করে — অন্য কোনো ফোল্ডার রিকার্সিভভাবে সার্চ করে না, অন্য কোনো ফাইল/ফোল্ডার ডিলিট করে না। তোমার দেওয়া requirement অনুযায়ী scope ইচ্ছাকৃতভাবে narrow রাখা হয়েছে।
- MIUI (Xiaomi/Redmi) তে battery optimization এর কারণে ARM করা থাকলেও ব্যাকগ্রাউন্ড সার্ভিস কিছুক্ষণ পর বন্ধ হয়ে যেতে পারে। প্রয়োজনে Settings → Apps → nomedia-fix → Battery saver → **No restrictions** করে রাখো।
- Shizuku নিজে root না, কিন্তু root-এর সমতুল্য access দেয় ADB পরিচয়ে (shell, UID 2000) — এটা একটা well-known, widely-used, open-source টুল, কিন্তু ব্যবহারের আগে এটা যে কী এবং কীভাবে কাজ করে এটা বোঝা ভালো।

---

## প্রজেক্ট ফাইল গঠন

```
NoMediaFix/
├── build.gradle, settings.gradle, gradle.properties
└── app/
    ├── build.gradle                     (Shizuku dependency, AIDL build feature)
    └── src/main/
        ├── AndroidManifest.xml          (ShizukuProvider declaration সহ)
        ├── aidl/.../IUserService.aidl   (প্রিভিলেজড প্রসেসের interface)
        ├── java/com/sdcardfix/nomediafix/
        │   ├── MainActivity.kt          (UI, permission flow, arm/run বাটন)
        │   ├── UserService.kt           (প্রিভিলেজড প্রসেসে চলে — আসল delete logic)
        │   ├── ShizukuHelper.kt         (permission check/request, binding)
        │   ├── CardWatcherService.kt    (ARM করলে চালু হয়, কার্ড মাউন্ট ধরে)
        │   ├── LogStore.kt              (টার্মিনাল-স্টাইল লগ পার্সিস্ট করে)
        │   └── BootReceiver.kt          (রিবুটের পর ARM ছিল কিনা চেক করে সার্ভিস restart করে)
        └── res/
            ├── layout/activity_main.xml (ডার্ক, monospace, টার্মিনাল-স্টাইল UI)
            ├── values/                  (strings, colors — dark dev theme)
            └── mipmap/, drawable/       (app icon — terminal prompt স্টাইল)
```
