// IUserService.aidl
package com.sdcardfix.nomediafix;

interface IUserService {

    // ঠিক /storage/<volume-id>/Android/data/.nomedia পথ চেক করে, থাকলে ডিলিট করে।
    // অন্য কোনো ফোল্ডার বা ফাইল touch করে না। রিটার্ন ভ্যালু একটা লাইন-বাই-লাইন
    // রিপোর্ট, যেমন "DELETED:/storage/XXXX-XXXX/Android/data/.nomedia"।
    String runCleanup();

    // Shizuku এর নিজস্ব কনভেনশন — এই প্রিভিলেজড প্রসেস বন্ধ করার জন্য।
    // সংখ্যাটা পরিবর্তন করা যাবে না, Shizuku নিজে এটা ব্যবহার করে।
    void destroy() = 16777114;
}
