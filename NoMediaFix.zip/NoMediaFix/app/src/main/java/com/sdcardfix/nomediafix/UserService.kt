package com.sdcardfix.nomediafix

import java.io.File

/**
 * এই ক্লাস Shizuku এর প্রিভিলেজড প্রসেসে (root বা shell পরিচয়ে) রান করে — এটা
 * normal app sandbox এর বাইরে, তাই Android এর Scoped Storage restriction এখানে
 * প্রযোজ্য না। ঠিক এই কারণেই "Android/data" ফোল্ডারে অ্যাক্সেস সম্ভব হয়।
 *
 * স্কোপ ইচ্ছাকৃতভাবে সংকীর্ণ রাখা হয়েছে — এই ক্লাস ঠিক একটাই জিনিস চেক করে:
 * /storage/<volume-id>/Android/data/.nomedia
 *
 * প্রতিটা মাউন্ট হওয়া volume (SD card) এর জন্য এই exact পথ চেক করা হয়, এবং
 * ফাইল পাওয়া গেলে শুধু সেটাই ডিলিট করা হয়। অন্য কোনো ফোল্ডার, অন্য কোনো
 * ".nomedia" ফাইল (যেমন কোনো app এর সাবফোল্ডারে থাকা), বা রিকার্সিভ কোনো সার্চ —
 * কিছুই করা হয় না।
 */
class UserService : IUserService.Stub() {

    override fun runCleanup(): String {
        val log = StringBuilder()
        val storageRoot = File("/storage")
        val volumes = storageRoot.listFiles { f -> f.isDirectory } ?: emptyArray()

        var foundAny = false
        for (vol in volumes) {
            val name = vol.name
            // "emulated" হলো ফোনের নিজস্ব ইন্টারনাল স্টোরেজ, "self" একটা সিম্বলিক লিংক —
            // এগুলো removable SD card না, তাই স্কিপ করা হচ্ছে।
            if (name == "emulated" || name == "self") continue

            val target = File(vol, "Android/data/.nomedia")

            if (target.exists()) {
                foundAny = true
                val deleted = target.delete()
                log.append(
                    if (deleted) "DELETED:${target.absolutePath}\n"
                    else "FAILED:${target.absolutePath}\n"
                )
            }
        }

        if (!foundAny) {
            log.append("NOT_FOUND\n")
        }

        return log.toString()
    }

    override fun destroy() {
        System.exit(0)
    }
}
