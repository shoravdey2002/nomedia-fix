package com.sdcardfix.nomediafix

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * এই সার্ভিস তখনই চালু হয় যখন ইউজার "arm" করে — কোনো continuous background
 * monitoring না, ইচ্ছাকৃতভাবে। Arm করা থাকলে কার্ড mount হওয়ার ইভেন্ট ধরে,
 * এবং সাথে সাথে Shizuku এর মাধ্যমে স্কোপড cleanup চালায়।
 */
class CardWatcherService : Service() {

    private var mountReceiver: BroadcastReceiver? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification(getString(R.string.notif_armed)))
        registerMountReceiver()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        mountReceiver?.let {
            try {
                unregisterReceiver(it)
            } catch (e: IllegalArgumentException) {
                // আগেই আনরেজিস্টার্ড থাকতে পারে
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun registerMountReceiver() {
        mountReceiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                if (intent?.action == Intent.ACTION_MEDIA_MOUNTED) {
                    handleCardMounted()
                }
            }
        }
        val filter = IntentFilter(Intent.ACTION_MEDIA_MOUNTED)
        filter.addDataScheme("file")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(mountReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(mountReceiver, filter)
        }
    }

    private fun handleCardMounted() {
        LogStore.append(this, getString(R.string.log_card_mounted))

        if (!ShizukuHelper.hasPermission()) {
            LogStore.append(this, getString(R.string.log_no_permission))
            return
        }

        ShizukuHelper.runCleanup(this) { result ->
            val lines = result.split("\n").filter { it.isNotBlank() }
            var deletedAny = false

            for (line in lines) {
                when {
                    line.startsWith("DELETED:") -> {
                        deletedAny = true
                        LogStore.append(this, getString(R.string.log_deleted, line.removePrefix("DELETED:")))
                    }
                    line.startsWith("FAILED:") ->
                        LogStore.append(this, getString(R.string.log_failed, line.removePrefix("FAILED:")))
                    line == "NOT_FOUND" ->
                        LogStore.append(this, getString(R.string.log_not_found))
                    line.startsWith("ERROR:") ->
                        LogStore.append(this, getString(R.string.log_error, line.removePrefix("ERROR:")))
                }
            }

            val nm = getSystemService(NotificationManager::class.java)
            val text = if (deletedAny) getString(R.string.notif_cleaned) else getString(R.string.notif_not_found)
            nm.notify(NOTIF_RESULT_ID, buildNotification(text))
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, getString(R.string.channel_name), NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val CHANNEL_ID = "card_watcher_channel"
        const val NOTIF_ID = 2001
        const val NOTIF_RESULT_ID = 2002

        fun start(context: Context) {
            context.startForegroundService(Intent(context, CardWatcherService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, CardWatcherService::class.java))
        }
    }
}
