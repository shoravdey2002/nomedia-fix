package com.sdcardfix.nomediafix

import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.sdcardfix.nomediafix.databinding.ActivityMainBinding
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: SharedPreferences

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == SHIZUKU_REQUEST_CODE) {
                val granted = grantResult == PackageManager.PERMISSION_GRANTED
                runOnUiThread {
                    LogStore.append(
                        this,
                        getString(if (granted) R.string.log_permission_granted else R.string.log_permission_denied)
                    )
                    refreshUi()
                }
            }
        }

    private val notifPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* permission না দিলেও অ্যাপ চলবে, শুধু নোটিফিকেশন দেখাবে না */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)

        Shizuku.addRequestPermissionResultListener(permissionResultListener)

        binding.btnRequestPermission.setOnClickListener { requestShizukuPermission() }
        binding.btnArmToggle.setOnClickListener { toggleArm() }
        binding.btnRunNow.setOnClickListener { runNow() }
        binding.btnClearLog.setOnClickListener {
            LogStore.clear(this)
            refreshUi()
        }

        requestNotificationPermissionIfNeeded()

        if (LogStore.getAll(this).isBlank()) {
            LogStore.append(this, getString(R.string.log_app_started))
        }
        refreshUi()
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeRequestPermissionResultListener(permissionResultListener)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this, android.Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notifPermLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun requestShizukuPermission() {
        if (!ShizukuHelper.isShizukuInstalled()) {
            Toast.makeText(this, getString(R.string.toast_install_shizuku), Toast.LENGTH_LONG).show()
            return
        }
        if (ShizukuHelper.hasPermission()) {
            LogStore.append(this, getString(R.string.log_permission_granted))
            refreshUi()
            return
        }
        ShizukuHelper.requestPermission(SHIZUKU_REQUEST_CODE)
    }

    private fun toggleArm() {
        val armed = prefs.getBoolean(KEY_ARMED, false)
        if (!armed) {
            if (!ShizukuHelper.hasPermission()) {
                Toast.makeText(this, getString(R.string.toast_need_permission), Toast.LENGTH_LONG).show()
                return
            }
            prefs.edit().putBoolean(KEY_ARMED, true).apply()
            CardWatcherService.start(this)
            LogStore.append(this, getString(R.string.log_armed))
        } else {
            prefs.edit().putBoolean(KEY_ARMED, false).apply()
            CardWatcherService.stop(this)
            LogStore.append(this, getString(R.string.log_disarmed))
        }
        refreshUi()
    }

    private fun runNow() {
        if (!ShizukuHelper.hasPermission()) {
            Toast.makeText(this, getString(R.string.toast_need_permission), Toast.LENGTH_LONG).show()
            return
        }
        LogStore.append(this, getString(R.string.log_run_now))
        refreshUi()

        ShizukuHelper.runCleanup(this) { result ->
            runOnUiThread {
                handleCleanupResult(result)
                refreshUi()
            }
        }
    }

    private fun handleCleanupResult(result: String) {
        val lines = result.split("\n").filter { it.isNotBlank() }
        if (lines.isEmpty()) {
            LogStore.append(this, getString(R.string.log_not_found))
            return
        }
        for (line in lines) {
            when {
                line.startsWith("DELETED:") ->
                    LogStore.append(this, getString(R.string.log_deleted, line.removePrefix("DELETED:")))
                line.startsWith("FAILED:") ->
                    LogStore.append(this, getString(R.string.log_failed, line.removePrefix("FAILED:")))
                line == "NOT_FOUND" ->
                    LogStore.append(this, getString(R.string.log_not_found))
                line.startsWith("ERROR:") ->
                    LogStore.append(this, getString(R.string.log_error, line.removePrefix("ERROR:")))
            }
        }
    }

    private fun refreshUi() {
        binding.tvShizukuStatus.text = when {
            !ShizukuHelper.isShizukuInstalled() -> getString(R.string.status_shizuku_not_installed)
            !ShizukuHelper.hasPermission() -> getString(R.string.status_shizuku_no_permission)
            else -> getString(R.string.status_shizuku_ready)
        }

        val armed = prefs.getBoolean(KEY_ARMED, false)
        binding.tvWatcherStatus.text =
            if (armed) getString(R.string.status_watcher_armed) else getString(R.string.status_watcher_idle)
        binding.btnArmToggle.text =
            if (armed) getString(R.string.btn_disarm) else getString(R.string.btn_arm)

        binding.tvLog.text = LogStore.getAll(this).ifBlank { "—" }
    }

    companion object {
        const val PREFS_NAME = "nomediafix_prefs"
        const val KEY_ARMED = "armed"
        const val SHIZUKU_REQUEST_CODE = 1001
    }
}
