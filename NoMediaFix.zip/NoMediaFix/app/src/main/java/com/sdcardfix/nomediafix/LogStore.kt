package com.sdcardfix.nomediafix

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * টার্মিনাল-স্টাইল লগ এরিয়ার পেছনে থাকা সাধারণ persistent স্টোরেজ।
 * MainActivity আর CardWatcherService — দুজনেই এখানে লাইন যুক্ত করতে পারে,
 * যাতে app বন্ধ থাকলেও আগের কাজের ইতিহাস দেখা যায়।
 */
object LogStore {
    private const val PREFS_NAME = "nomediafix_log"
    private const val KEY_ENTRIES = "entries"
    private const val MAX_ENTRIES = 60

    fun append(context: Context, message: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val existing = prefs.getString(KEY_ENTRIES, "") ?: ""
        val timestamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val line = "[$timestamp] $message"
        val lines = (existing.split("\n").filter { it.isNotBlank() } + line).takeLast(MAX_ENTRIES)
        prefs.edit().putString(KEY_ENTRIES, lines.joinToString("\n")).apply()
    }

    fun getAll(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_ENTRIES, "") ?: ""
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
