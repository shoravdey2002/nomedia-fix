package com.sdcardfix.nomediafix

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val prefs = context.getSharedPreferences(MainActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val armed = prefs.getBoolean(MainActivity.KEY_ARMED, false)
            if (armed) {
                CardWatcherService.start(context)
            }
        }
    }
}
