package com.sdcardfix.nomediafix

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import rikka.shizuku.Shizuku

/**
 * Shizuku এর সাথে সব communication এই অবজেক্টের মধ্য দিয়ে হয়।
 * MainActivity আর CardWatcherService — দুইটাই এটা ব্যবহার করে, যেহেতু দুটোই
 * একই app process এর ভেতরে থাকে (আলাদা :process declare করা হয়নি)।
 */
object ShizukuHelper {

    private const val SERVICE_VERSION = 1
    private var connection: ServiceConnection? = null

    private fun buildArgs(context: Context): Shizuku.UserServiceArgs {
        return Shizuku.UserServiceArgs(
            ComponentName(context.packageName, UserService::class.java.name)
        )
            .daemon(true)
            .processNameSuffix("privileged")
            .debuggable(false)
            .version(SERVICE_VERSION)
            .tag("nomediafix_userservice")
    }

    fun isShizukuInstalled(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (e: Throwable) {
            false
        }
    }

    fun hasPermission(): Boolean {
        return try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Throwable) {
            false
        }
    }

    fun requestPermission(requestCode: Int) {
        try {
            Shizuku.requestPermission(requestCode)
        } catch (e: Throwable) {
            // Shizuku চালু নেই বা বাইন্ডার এখনো পাওয়া যায়নি
        }
    }

    /**
     * প্রিভিলেজড প্রসেসে bind করে runCleanup() কল করে, রেজাল্ট callback এ পাঠায়।
     * রেজাল্ট স্ট্রিং এর প্রতি লাইন "DELETED:...", "FAILED:...", বা "NOT_FOUND" ফরম্যাটে থাকে।
     */
    fun runCleanup(context: Context, onResult: (String) -> Unit) {
        if (!hasPermission()) {
            onResult("ERROR:no_permission")
            return
        }

        val args = buildArgs(context)
        val newConnection = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName, binder: IBinder) {
                try {
                    val service = IUserService.Stub.asInterface(binder)
                    val result = service.runCleanup()
                    onResult(result)
                } catch (e: Exception) {
                    onResult("ERROR:${e.message}")
                }
            }

            override fun onServiceDisconnected(name: ComponentName) {
                // কিছু করার নেই, প্রতিটা runCleanup() কল তার নিজের connection বানায়
            }
        }
        connection = newConnection
        try {
            Shizuku.bindUserService(args, newConnection)
        } catch (e: Throwable) {
            onResult("ERROR:bind_failed_${e.message}")
        }
    }
}
